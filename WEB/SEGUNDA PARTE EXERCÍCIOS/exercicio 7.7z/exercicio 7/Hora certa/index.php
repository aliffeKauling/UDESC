<?php

echo 'Hoje é:';
echo date("d/m/Y");

echo 'e agora é:';

echo date('h:i').'h';
?>
