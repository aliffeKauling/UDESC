<?php
    /*string strtoupper (string conteudo)*/
    $nome = "joel rodrigues";
    $nome_maisculo = strtoupper($nome);
    echo $nome_maisculo;
?>


