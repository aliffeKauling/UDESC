<?php
$cookie_name = "site";
$cookie_value = "Desenvolvimento de aplicações WEB";
setcookie($cookie_name, $cookie_value, time() + (86400 * 30)); // 86400 = 1 dia

if(!isset($_COOKIE[$cookie_name])) { // verifica se o cookie_name está definido
     echo "O cookie'" . $cookie_name . "' não está definido!";
} else {
     echo "O valor do cookie '" . $cookie_name . "' é ".$_COOKIE['site']." !<br>";
}


